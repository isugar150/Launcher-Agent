param($installPath, $toolsPath, $package, $project)
$DTE.ItemOperations.Navigate("http://vtortola.github.io/WebSocketListener?nuget")